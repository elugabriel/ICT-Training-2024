var cel = 100

var fer = (cel * 9/5) + 32
 //divi = 9/5
//console.log(fer)


var principal = 500000
var rate = 1.7
var time = 7
Simple_Interest = (principal * rate * time) / 100

//console.log(Simple_Interest)


// String
var lastName = 'Deborah'
var firstName = 'Paul'
var middle_name;
var full_name = firstName + " "+ lastName
middle_name = "John"
var welcome = `Welcome, ${full_name}`
// console.log(welcome)
// console.log(firstName[1])
// console.log(middle_name)

let sym1 = Symbol('description');
let sym2 = Symbol('description');
console.log(sym1 === sym2); 


// object data type

let person = {
    name: 'Alice',
    age: 30,
    loc: "Nsukka"
    
  };

console.log(person.name)
console.log(person.loc)

