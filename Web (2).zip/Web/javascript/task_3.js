var num;
num = 56;

if(num == 0){
    console.log(num + " is zero");
}

else if(num < 0){
    console.log(num + " is Negative");
}

else{ 
    console.log(num + " is Positive");     

}