var age;
age = 14;

if (age >= 0 && age <= 12) {
    console.log("You are a Child.");
} else if (age >= 13 && age <= 19) {
    console.log("You are a Teenager.");
} else if (age >= 20 && age <= 64) {
    console.log("You are an Adult.");
} else if (age >= 65) {
    console.log("You are a Senior.");
} else {
    console.log("Invalid age entered.");
}