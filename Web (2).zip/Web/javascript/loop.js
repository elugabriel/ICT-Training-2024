var count;
count =2
while(count<= 20){
    if(count % 2 != 0){
        console.log(count);
    }

    count = count + 1

    // console.log(count);
    // //count++;
    // count = count + 2;
    
}

for(count =2; count<=20; count++){
    console.log(count)
}