var day;
day = 'Wednesday';

switch (day) {
    case 'Monday':
      console.log('Start of the work week.');
      break;
    case 'Wednesday':
      console.log('Midweek.');
      break;
    case 'Friday':
      console.log('Weekend is near.');
      break;
    default:
      console.log('Another day.');
  }