var num_1 = 24
var num_2 = '24'
var num_3 = '34'
var num_4 = 23.6

var num_5 = Number(num_3)

num_5 = String(num_5)

// console.log(typeof num_1)
// console.log(typeof num_2)
// console.log(num_1 + num_5)

// console.log(typeof num_5)
var voting_age = 18
var gender = 'f'
var userAge = 33

if(userAge < voting_age){
    console.log("You are Underage")
}

else if(userAge >= voting_age && userAge < 50){
    if(gender == "m" ){
        console.log("You are not Eligible")
    }
    else{
        console.log("You are Eligible to Vote ")
    }
    // 
}

else{
    console.log("You are too Old, Go and rest")
}

