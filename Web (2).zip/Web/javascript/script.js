
var age = 23
var twi = 45


