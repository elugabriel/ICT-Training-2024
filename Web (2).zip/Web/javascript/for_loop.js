const fruits = ["Apple", "Banana", "Cherry", "Date", "Grape", "Kiwi", "Lemon", "Mango", "Orange", "Peach", "Pear", "Pineapple", "Strawberry", "Watermelon"];


// console.log(fruits.length);

// for (let i = 0; i < fruits.length; i++) {
//       console.log(fruits[i]);
//     }

    // for (let i = 1; i <= 3; i++) {
    //     for (let j = 1; j <= 3; j++) {
    //       console.log(`i: ${i}, j: ${j}`);
    //     }
    //   }


for(let i = 2; i <= 5; i++){
    for(let j = 1; j <= 12; j++){
        //console.log(`${i} x ${j} = ${i*j}`);
    }


}


for (let i = 0; i < 10; i++) {
    if (i === 5) {
    //   break;  // Loop stops when i equals 5
      continue;
    }
    console.log(i);
  }
  