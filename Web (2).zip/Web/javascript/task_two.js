console.log("###########Task 1: Age Category Checker ##########")

let age = 46;

if (age >= 0 && age <= 12) {
  console.log("You are a Child.");
} else if (age >= 13 && age <= 19) {
  console.log("You are a Teenager.");
} else if (age >= 20 && age <= 64) {
  console.log("You are an Adult.");
} else if (age >= 65) {
  console.log("You are a Senior.");
} else {
  console.log("Invalid age entered.");
}


console.log("########### Task 2: Leap Year Checker ##########")

let year = 2023;

if ((year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0)) {
  console.log(year + " is a leap year.");
} else {
  console.log(year + " is not a leap year.");
}


console.log("########### Task 3: Positive, Negative, or Zero ##########")

let number =  -10;

if (number > 0) {
  console.log("The number is positive.");
} else if (number < 0) {
  console.log("The number is negative.");
} else {
  console.log("The number is zero.");
}


console.log("########### Task 4: Number Range Checker ##########")

let test_number = 45;

if (test_number >= 1 && test_number <= 100) {
  console.log("In range.");
} else {
  console.log("Out of range.");
}