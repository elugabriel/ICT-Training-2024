# ict-training
This is strictly for training purpose
